import { ArrowLeft, Instagram, MessageCircle } from "lucide-react";
import { Link } from "wouter";

const WHATSAPP_URL = "https://wa.me/553599335278";
const INSTAGRAM_URL = "https://www.instagram.com/_barbeariafidelis_/";

export default function Privacy() {
  return (
    <main className="legal-page">
      <nav className="legal-nav" aria-label="Navegação de privacidade">
        <Link href="/" className="brand-mark" aria-label="Voltar para a Barbearia Fidelis">
          <span className="brand-mark__line" />
          <span>FIDELIS</span>
          <small>BARBEARIA</small>
        </Link>
        <Link href="/" className="text-link"><ArrowLeft size={16} aria-hidden="true" /> Voltar</Link>
      </nav>

      <article className="legal-content">
        <span className="eyebrow">LGPD · ATUALIZADO EM SETEMBRO DE 2026</span>
        <h1>Política de<br /><em>Privacidade.</em></h1>
        <p className="legal-lead">Esta política explica como a Barbearia Fidelis trata os dados pessoais enviados no agendamento online.</p>

        <section>
          <h2>1. Dados coletados</h2>
          <p>Coletamos apenas o nome, o número de WhatsApp e as informações de data e horário necessários para registrar, confirmar e lembrar o seu agendamento.</p>
        </section>
        <section>
          <h2>2. Finalidade e base legal</h2>
          <p>Os dados são usados para executar o agendamento solicitado por você, organizar a agenda e enviar o lembrete de horário. O tratamento é limitado a essas finalidades e se apoia na execução de procedimentos relacionados ao seu pedido.</p>
        </section>
        <section>
          <h2>3. Compartilhamento e segurança</h2>
          <p>O número de WhatsApp pode ser encaminhado ao provedor de mensagens estritamente para o envio do lembrete. Adotamos medidas técnicas razoáveis para restringir o acesso às informações e não comercializamos dados pessoais.</p>
        </section>
        <section>
          <h2>4. Seus direitos</h2>
          <p>Você pode solicitar confirmação de tratamento, acesso, correção, exclusão ou informações sobre o uso dos seus dados. Para isso, entre em contato pelos canais oficiais abaixo.</p>
        </section>

        <div className="legal-contact">
          <a href={WHATSAPP_URL} target="_blank" rel="noreferrer"><MessageCircle size={18} aria-hidden="true" /> Falar pelo WhatsApp</a>
          <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer"><Instagram size={18} aria-hidden="true" /> Perfil no Instagram</a>
        </div>
      </article>
    </main>
  );
}
