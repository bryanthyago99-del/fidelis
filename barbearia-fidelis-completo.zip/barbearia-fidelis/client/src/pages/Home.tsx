import { CalendarDays, CheckCircle2, ChevronRight, Clock3, Instagram, Loader2, MapPin, MessageCircle, Sparkles } from "lucide-react";
import { FormEvent, useMemo, useState } from "react";
import { Link } from "wouter";
import { APPOINTMENT_SLOTS } from "@shared/appointments";
import { trpc } from "@/lib/trpc";

const WHATSAPP_URL = "https://wa.me/553599335278";
const INSTAGRAM_URL = "https://www.instagram.com/_barbeariafidelis_/";

function formatPhone(value: string) {
  const numbers = value.replace(/\D/g, "").slice(0, 11);
  if (numbers.length <= 2) return numbers;
  if (numbers.length <= 7) return `(${numbers.slice(0, 2)}) ${numbers.slice(2)}`;
  return `(${numbers.slice(0, 2)}) ${numbers.slice(2, 7)}-${numbers.slice(7)}`;
}

function getDateOptions() {
  const dates: Date[] = [];
  const cursor = new Date();
  cursor.setHours(12, 0, 0, 0);
  while (dates.length < 6) {
    dates.push(new Date(cursor));
    cursor.setDate(cursor.getDate() + 1);
  }
  return dates;
}

export default function Home() {
  const dateOptions = useMemo(getDateOptions, []);
  const [step, setStep] = useState(1);
  const [selectedDate, setSelectedDate] = useState(dateOptions[0]?.toISOString().slice(0, 10) ?? "");
  const [selectedTime, setSelectedTime] = useState("");
  const [name, setName] = useState("");
  const [whatsapp, setWhatsapp] = useState("");
  const [bookingComplete, setBookingComplete] = useState(false);

  const availability = trpc.appointments.available.useQuery({ date: selectedDate }, { enabled: Boolean(selectedDate) });
  const createAppointment = trpc.appointments.create.useMutation({
    onSuccess: () => {
      setBookingComplete(true);
      availability.refetch();
    },
  });

  const unavailableSlots = new Set(availability.data?.bookedTimes ?? []);
  const selectedDateLabel = useMemo(() => {
    const found = dateOptions.find((item) => item.toISOString().slice(0, 10) === selectedDate);
    return found?.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long" }) ?? selectedDate;
  }, [dateOptions, selectedDate]);

  function selectDate(value: string) {
    setSelectedDate(value);
    setSelectedTime("");
    setStep(2);
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedDate || !selectedTime) return;
    createAppointment.mutate({ name, whatsapp, date: selectedDate, time: selectedTime });
  }

  return (
    <div className="site-shell">
      <header className="container topbar">
        <a href="#inicio" className="brand-mark" aria-label="Barbearia Fidelis — início">
          <span className="brand-mark__line" />
          <span>FIDELIS</span>
          <small>BARBEARIA</small>
        </a>
        <div className="topbar__actions">
          <a className="nav-link" href={INSTAGRAM_URL} target="_blank" rel="noreferrer"><Instagram size={16} aria-hidden="true" /> Instagram</a>
          <a className="button-primary" href="#agendamento"><CalendarDays size={16} aria-hidden="true" /> Agendar horário</a>
        </div>
      </header>

      <main id="inicio">
        <section className="hero" aria-labelledby="hero-title">
          <div className="container hero-grid">
            <div className="hero-copy">
              <span className="eyebrow">CAMPESTRE · MINAS GERAIS</span>
              <h1 id="hero-title">Seu tempo.<br />Seu <em>estilo.</em></h1>
              <p>Uma experiência de agendamento direta, pontual e sem complicações. Escolha o melhor horário e reserve seu momento na Barbearia Fidelis.</p>
              <div className="hero-actions">
                <a className="button-primary" href="#agendamento"><CalendarDays size={18} aria-hidden="true" /> Escolher horário</a>
                <a className="button-ghost" href={WHATSAPP_URL} target="_blank" rel="noreferrer"><MessageCircle size={18} aria-hidden="true" /> WhatsApp</a>
              </div>
              <div className="hero-meta">
                <span><MapPin size={14} aria-hidden="true" /> Campestre-MG</span>
                <span><Clock3 size={14} aria-hidden="true" /> Agenda online</span>
              </div>
            </div>

            <section id="agendamento" className="booking-card" aria-labelledby="booking-title">
              <div className="booking-card__top">
                <div>
                  <span className="eyebrow">AGENDE ONLINE</span>
                  <h2 id="booking-title">Reserve seu horário</h2>
                </div>
                <span className="booking-card__id">01—03</span>
              </div>
              <div className="steps" aria-label={`Etapa ${Math.min(step, 3)} de 3`}>
                {[1, 2, 3].map((number) => <span className={step >= number ? "active" : ""} key={number} />)}
              </div>

              {bookingComplete ? (
                <div className="booking-success" role="status" aria-live="polite">
                  <CheckCircle2 size={34} aria-hidden="true" />
                  <h3>Horário reservado.</h3>
                  <p>Seu agendamento para {selectedDateLabel} às {selectedTime} foi registrado. Você receberá um lembrete pelo WhatsApp.</p>
                  <button className="back-button" onClick={() => { setBookingComplete(false); setStep(1); setSelectedTime(""); }}>Fazer novo agendamento</button>
                </div>
              ) : (
                <>
                  {step === 1 && (
                    <div className="booking-step">
                      <p className="booking-step__label">PASSO 01 · DATA</p>
                      <h3>Qual dia funciona para você?</h3>
                      <div className="date-grid" role="group" aria-label="Escolha a data">
                        {dateOptions.map((date) => {
                          const value = date.toISOString().slice(0, 10);
                          return <button type="button" className="date-chip" aria-pressed={selectedDate === value} onClick={() => selectDate(value)} key={value}>
                            <span className="date-chip__weekday">{date.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", "")}</span>
                            <span className="date-chip__number">{date.getDate()}</span>
                          </button>;
                        })}
                      </div>
                    </div>
                  )}

                  {step === 2 && (
                    <div className="booking-step">
                      <p className="booking-step__label">PASSO 02 · HORÁRIO</p>
                      <h3>Escolha um horário livre.</h3>
                      {availability.isLoading ? <div className="booking-feedback"><Loader2 size={16} className="animate-spin" aria-hidden="true" /> Consultando disponibilidade...</div> :
                        <div className="slot-grid" role="group" aria-label="Escolha o horário">
                          {APPOINTMENT_SLOTS.map((time) => <button type="button" className="slot" key={time} disabled={unavailableSlots.has(time)} aria-pressed={selectedTime === time} onClick={() => { setSelectedTime(time); setStep(3); }}>{time}</button>)}
                        </div>}
                      {availability.isError && <p className="booking-feedback error" role="alert">Não foi possível consultar a agenda agora. Tente novamente em instantes.</p>}
                    </div>
                  )}

                  {step === 3 && (
                    <form className="booking-step" onSubmit={handleSubmit}>
                      <p className="booking-step__label">PASSO 03 · CONFIRMAÇÃO</p>
                      <h3>Falta pouco.</h3>
                      <div className="details-form">
                        <label>Seu nome
                          <input value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" placeholder="Como podemos te chamar?" minLength={2} maxLength={100} required />
                        </label>
                        <label>Seu WhatsApp
                          <input value={whatsapp} onChange={(event) => setWhatsapp(formatPhone(event.target.value))} autoComplete="tel" inputMode="numeric" placeholder="(00) 00000-0000" minLength={14} required />
                        </label>
                      </div>
                      {createAppointment.isError && <p className="booking-feedback error" role="alert">{createAppointment.error.message}</p>}
                      <div className="booking-card__footer">
                        <button className="back-button" type="button" onClick={() => setStep(2)}>Voltar</button>
                        <button className="button-primary submit-button" type="submit" disabled={createAppointment.isPending}>{createAppointment.isPending ? <Loader2 size={14} className="animate-spin" aria-hidden="true" /> : <Sparkles size={14} aria-hidden="true" />} Confirmar</button>
                      </div>
                    </form>
                  )}
                  {step < 3 && <div className="booking-card__footer"><span className="booking-step__label">{step === 1 ? "Selecione uma data" : `${selectedDateLabel} · ${selectedTime || "Escolha um horário"}`}</span>{step === 2 && <button className="back-button" type="button" onClick={() => setStep(1)}>Voltar</button>}</div>}
                </>
              )}
            </section>
          </div>
        </section>

        <section className="section section--gallery" aria-labelledby="instagram-title">
          <div className="container">
            <div className="section-head">
              <div>
                <span className="eyebrow">@_BARBEARIAFIDELIS_</span>
                <h2 className="section-title" id="instagram-title">Acompanhe a <em>Fidelis</em> no Instagram.</h2>
              </div>
              <p className="section-copy">Uma seleção visual vinculada ao perfil oficial. As imagens autorizadas serão exibidas aqui após o envio dos arquivos pela barbearia.</p>
            </div>
            <a className="gallery-grid" href={INSTAGRAM_URL} target="_blank" rel="noreferrer" aria-label="Abrir o Instagram oficial da Barbearia Fidelis">
              {["01", "02", "03"].map((number) => <span className="gallery-card" key={number}>
                <span className="gallery-card__number">INSTAGRAM / {number}</span>
                <span className="gallery-card__bottom"><strong>Ver conteúdo no perfil oficial</strong><Instagram size={25} aria-hidden="true" /></span>
              </span>)}
            </a>
            <p className="gallery-note">As três fotos serão incorporadas somente a partir de imagens autorizadas e fornecidas pela Barbearia Fidelis.</p>
          </div>
        </section>

        <section className="contact-band" aria-labelledby="contact-title">
          <div className="container contact-band__inner">
            <div>
              <span className="eyebrow">SEM COMPLICAÇÃO</span>
              <h2 id="contact-title">Prefere falar diretamente?</h2>
            </div>
            <a className="button-ghost" href={WHATSAPP_URL} target="_blank" rel="noreferrer"><MessageCircle size={18} aria-hidden="true" /> Chamar no WhatsApp</a>
          </div>
        </section>
      </main>

      <footer className="site-footer">
        <div className="container">
          <div className="footer-grid">
            <div>
              <a href="#inicio" className="brand-mark" aria-label="Voltar ao início"><span className="brand-mark__line" /><span>FIDELIS</span><small>BARBEARIA</small></a>
              <p className="footer-copy">Agendamento online simples para Campestre-MG.</p>
            </div>
            <div className="footer-links">
              <a href={WHATSAPP_URL} target="_blank" rel="noreferrer">+55 35 9933-5278</a>
              <a href={INSTAGRAM_URL} target="_blank" rel="noreferrer">Instagram oficial</a>
            </div>
            <div className="footer-links">
              <Link href="/privacidade">Privacidade</Link>
              <Link href="/termos">Termos</Link>
            </div>
          </div>
          <div className="footer-foot"><span>© {new Date().getFullYear()} Barbearia Fidelis</span><span>Campestre · MG · Brasil</span></div>
        </div>
      </footer>
    </div>
  );
}
