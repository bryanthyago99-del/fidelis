import { ArrowLeft, CalendarDays } from "lucide-react";
import { Link } from "wouter";

export default function NotFound() {
  return (
    <main className="not-found-page">
      <div className="not-found-grid" aria-hidden="true" />
      <div className="not-found-content">
        <span className="eyebrow">BARBEARIA FIDELIS · CAMPESTRE-MG</span>
        <p className="not-found-code">404</p>
        <h1>Este caminho não<br /><em>está na agenda.</em></h1>
        <p>A página que você procura não foi encontrada. Volte ao início para escolher o seu próximo horário.</p>
        <Link href="/#agendamento" className="button-primary"><CalendarDays size={18} aria-hidden="true" /> Ir para agendamento</Link>
        <Link href="/" className="text-link"><ArrowLeft size={16} aria-hidden="true" /> Página inicial</Link>
      </div>
    </main>
  );
}
