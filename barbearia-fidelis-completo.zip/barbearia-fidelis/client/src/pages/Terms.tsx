import { ArrowLeft, MessageCircle } from "lucide-react";
import { Link } from "wouter";

const WHATSAPP_URL = "https://wa.me/553599335278";

export default function Terms() {
  return (
    <main className="legal-page">
      <nav className="legal-nav" aria-label="Navegação de termos">
        <Link href="/" className="brand-mark" aria-label="Voltar para a Barbearia Fidelis">
          <span className="brand-mark__line" />
          <span>FIDELIS</span>
          <small>BARBEARIA</small>
        </Link>
        <Link href="/" className="text-link"><ArrowLeft size={16} aria-hidden="true" /> Voltar</Link>
      </nav>

      <article className="legal-content">
        <span className="eyebrow">CONDIÇÕES DE USO · SETEMBRO DE 2026</span>
        <h1>Termos de<br /><em>Agendamento.</em></h1>
        <p className="legal-lead">Ao concluir uma reserva, você solicita a guarda do horário escolhido na agenda da Barbearia Fidelis.</p>

        <section>
          <h2>1. Reserva de horário</h2>
          <p>Os horários apresentados dependem da disponibilidade no momento da consulta. Um horário só é considerado reservado após a confirmação exibida nesta página.</p>
        </section>
        <section>
          <h2>2. Informações corretas</h2>
          <p>Você é responsável por informar nome e número de WhatsApp válidos. Esses dados são necessários para a identificação do agendamento e o envio do lembrete automático.</p>
        </section>
        <section>
          <h2>3. Alterações e cancelamentos</h2>
          <p>Se precisar alterar ou cancelar, entre em contato pelo WhatsApp oficial assim que possível. A agenda é atualizada conforme a disponibilidade existente.</p>
        </section>
        <section>
          <h2>4. Comunicação</h2>
          <p>O lembrete é uma conveniência e não substitui a confirmação direta do horário. Mensagens podem estar sujeitas à disponibilidade técnica do serviço de WhatsApp.</p>
        </section>

        <div className="legal-contact">
          <a href={WHATSAPP_URL} target="_blank" rel="noreferrer"><MessageCircle size={18} aria-hidden="true" /> Falar pelo WhatsApp</a>
        </div>
      </article>
    </main>
  );
}
