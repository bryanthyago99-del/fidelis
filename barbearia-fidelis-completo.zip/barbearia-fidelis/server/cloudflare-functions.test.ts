import { describe, expect, it } from "vitest";
import { onRequestGet } from "../cloudflare-pages/functions/api/availability.js";
import { onRequestPost } from "../cloudflare-pages/functions/api/appointments.js";

type QueryRecord = { sql: string; values: unknown[] };

function createD1Mock(options: { booked?: string[]; duplicate?: boolean } = {}) {
  const queries: QueryRecord[] = [];
  return {
    queries,
    prepare(sql: string) {
      return {
        bind: (...values: unknown[]) => ({
          async all() {
            queries.push({ sql, values });
            return { results: (options.booked ?? []).map((hora) => ({ hora })) };
          },
          async run() {
            queries.push({ sql, values });
            if (options.duplicate) throw new Error("UNIQUE constraint failed: agendamentos.data, agendamentos.hora");
            return { meta: { last_row_id: 42, changes: 1 } };
          },
        }),
      };
    },
  };
}

describe("Cloudflare Pages Functions", () => {
  it("retorna horários já reservados pela função de disponibilidade", async () => {
    const DB = createD1Mock({ booked: ["08:00", "10:00"] });
    const response = await onRequestGet({ env: { DB }, request: new Request("https://site.test/api/availability?data=2099-01-01") });
    expect(response.status).toBe(200);
    await expect(response.json()).resolves.toMatchObject({ bookedTimes: ["08:00", "10:00"] });
    expect(DB.queries[0]?.values).toEqual(["2099-01-01"]);
  });

  it("cria uma reserva normalizando o WhatsApp", async () => {
    const DB = createD1Mock();
    const request = new Request("https://site.test/api/appointments", { method: "POST", body: JSON.stringify({ nome: "Carlos", whatsapp: "(35) 9933-5278", data: "2099-01-01", hora: "08:00" }) });
    const response = await onRequestPost({ env: { DB }, request });
    expect(response.status).toBe(201);
    await expect(response.json()).resolves.toMatchObject({ id: 42, status: "confirmado", hora: "08:00" });
    expect(DB.queries[0]?.values).toEqual(["Carlos", "553599335278", "2099-01-01", "08:00"]);
  });

  it("rejeita conflito da restrição única de data e hora", async () => {
    const DB = createD1Mock({ duplicate: true });
    const request = new Request("https://site.test/api/appointments", { method: "POST", body: JSON.stringify({ nome: "Carlos", whatsapp: "(35) 9933-5278", data: "2099-01-01", hora: "08:00" }) });
    const response = await onRequestPost({ env: { DB }, request });
    expect(response.status).toBe(409);
    await expect(response.json()).resolves.toMatchObject({ error: "Esse horário acabou de ser reservado. Escolha outro." });
  });

  it("rejeita tentativa de agendamento em data passada", async () => {
    const DB = createD1Mock();
    const request = new Request("https://site.test/api/appointments", { method: "POST", body: JSON.stringify({ nome: "Carlos", whatsapp: "(35) 9933-5278", data: "2000-01-01", hora: "08:00" }) });
    const response = await onRequestPost({ env: { DB }, request });
    expect(response.status).toBe(400);
    await expect(response.json()).resolves.toMatchObject({ error: "Revise os dados do agendamento e tente novamente." });
    expect(DB.queries).toHaveLength(0);
  });
});
