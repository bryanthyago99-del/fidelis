import { afterEach, describe, expect, it, vi } from "vitest";
import { appointmentInstant, localComparableInstant, processReminders } from "../cloudflare-pages/worker/src/index.js";

describe("Worker de lembretes", () => {
  it("compara a hora de agendamento no relógio local de São Paulo", () => {
    const scheduled = appointmentInstant("2026-09-06", "10:00");
    const now = localComparableInstant(new Date("2026-09-06T12:00:00.000Z"));
    expect((scheduled - now) / 60_000).toBe(60);
  });

  it("envia o template exato e só confirma o lembrete após reivindicar a reserva", async () => {
    vi.useFakeTimers();
    vi.setSystemTime(new Date("2026-09-06T12:00:00.000Z"));
    const requests: Array<{ sql: string; values: unknown[] }> = [];
    const DB = {
      prepare(sql: string) {
        return {
          bind: (...values: unknown[]) => ({
            async all() {
              requests.push({ sql, values });
              return { results: [{ id: 7, nome: "Carlos", whatsapp: "553599335278", data: "2026-09-06", hora: "10:00" }] };
            },
            async run() {
              requests.push({ sql, values });
              return { meta: { changes: 1 } };
            },
          }),
        };
      },
    };
    const fetchMock = vi.fn().mockResolvedValue(new Response("{}", { status: 200 }));
    vi.stubGlobal("fetch", fetchMock);

    await processReminders({
      DB,
      WHATSAPP_TOKEN: "secret",
      WHATSAPP_PHONE_NUMBER_ID: "12345",
      WHATSAPP_TEMPLATE_NAME: "lembrete_agendamento",
      WHATSAPP_TEMPLATE_LANGUAGE: "pt_BR",
      WHATSAPP_API_VERSION: "v26.0",
    });

    expect(fetchMock).toHaveBeenCalledTimes(1);
    const sentPayload = JSON.parse(String((fetchMock.mock.calls[0]?.[1] as RequestInit).body));
    expect(sentPayload).toMatchObject({
      type: "template",
      to: "553599335278",
      template: {
        name: "lembrete_agendamento",
        language: { code: "pt_BR" },
        components: [{ type: "body", parameters: [{ type: "text", text: "Carlos" }, { type: "text", text: "10:00" }] }],
      },
    });
    expect(requests.some((request) => request.sql.includes("lembrete_estado = 'enviando'"))).toBe(true);
    expect(requests.some((request) => request.sql.includes("lembrete_estado = 'enviado'"))).toBe(true);
  });
});

afterEach(() => {
  vi.unstubAllGlobals();
  vi.useRealTimers();
});
