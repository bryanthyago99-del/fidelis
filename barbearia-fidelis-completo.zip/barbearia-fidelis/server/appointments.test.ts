import { describe, expect, it } from "vitest";
import { APPOINTMENT_SLOTS, isAllowedAppointmentTime, isValidAppointmentDate, isValidWhatsApp, normalizeWhatsApp } from "../shared/appointments";

describe("regras de agenda", () => {
  it("mantém exclusivamente os 19 horários de 40 minutos entre 08:00 e 20:00", () => {
    expect(APPOINTMENT_SLOTS).toHaveLength(19);
    expect(APPOINTMENT_SLOTS[0]).toBe("08:00");
    expect(APPOINTMENT_SLOTS.at(-1)).toBe("20:00");
    expect(APPOINTMENT_SLOTS.every((time) => isAllowedAppointmentTime(time))).toBe(true);
  });

  it("não aceita horários fora da grade definida", () => {
    expect(isAllowedAppointmentTime("07:20")).toBe(false);
    expect(isAllowedAppointmentTime("20:40")).toBe(false);
    expect(isAllowedAppointmentTime("08:30")).toBe(false);
  });

  it("normaliza e valida telefones brasileiros em formato internacional", () => {
    expect(normalizeWhatsApp("(35) 9933-5278")).toBe("553599335278");
    expect(isValidWhatsApp("(35) 9933-5278")).toBe(true);
    expect(isValidWhatsApp("12345")).toBe(false);
  });

  it("aceita somente datas ISO existentes", () => {
    expect(isValidAppointmentDate("2026-09-06")).toBe(true);
    expect(isValidAppointmentDate("2026-02-30")).toBe(false);
    expect(isValidAppointmentDate("06/09/2026")).toBe(false);
  });
});
