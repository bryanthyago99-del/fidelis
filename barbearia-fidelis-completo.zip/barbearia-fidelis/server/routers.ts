import { COOKIE_NAME } from "@shared/const";
import { APPOINTMENT_SLOTS, isAllowedAppointmentTime, isValidAppointmentDate, isValidWhatsApp, normalizeWhatsApp } from "@shared/appointments";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import { AppointmentSlotUnavailableError, createAppointment, getBookedTimes } from "./db";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";

function getSaoPauloDateTime() {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    hourCycle: "h23",
  }).formatToParts(new Date());
  const value = (type: Intl.DateTimeFormatPartTypes) => parts.find((part) => part.type === type)?.value ?? "";
  return { date: `${value("year")}-${value("month")}-${value("day")}`, time: `${value("hour")}:${value("minute")}` };
}

function assertValidBookingDate(date: string, time?: string) {
  const now = getSaoPauloDateTime();
  if (!isValidAppointmentDate(date) || date < now.date || (time && date === now.date && time <= now.time)) {
    throw new TRPCError({ code: "BAD_REQUEST", message: "Selecione uma data válida." });
  }
}

export const appRouter = router({
    // if you need to use socket.io, read and register route in server/_core/index.ts, all api should start with '/api/' so that the gateway can route correctly
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),
  appointments: router({
    available: publicProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ input }) => {
        assertValidBookingDate(input.date);
        const bookedTimes = await getBookedTimes(input.date);
        const now = getSaoPauloDateTime();
        const pastTimes = input.date === now.date ? APPOINTMENT_SLOTS.filter((time) => time <= now.time) : [];
        return { bookedTimes: Array.from(new Set([...bookedTimes, ...pastTimes])) };
      }),
    create: publicProcedure
      .input(z.object({
        name: z.string().trim().min(2).max(100),
        whatsapp: z.string().trim().min(10).max(25),
        date: z.string(),
        time: z.string(),
      }))
      .mutation(async ({ input }) => {
        assertValidBookingDate(input.date, input.time);
        if (!isAllowedAppointmentTime(input.time)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Selecione um horário disponível." });
        }
        if (!isValidWhatsApp(input.whatsapp)) {
          throw new TRPCError({ code: "BAD_REQUEST", message: "Informe um WhatsApp válido com DDD." });
        }

        try {
          const id = await createAppointment({
            name: input.name.trim(),
            whatsapp: normalizeWhatsApp(input.whatsapp),
            date: input.date,
            time: input.time,
            status: "confirmed",
          });
          return { id, date: input.date, time: input.time };
        } catch (error) {
          if (error instanceof AppointmentSlotUnavailableError) {
            throw new TRPCError({ code: "CONFLICT", message: "Esse horário acabou de ser reservado. Escolha outro." });
          }
          throw error;
        }
      }),
  }),
});

export type AppRouter = typeof appRouter;
