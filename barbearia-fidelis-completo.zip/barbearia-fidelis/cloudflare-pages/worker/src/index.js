const REMINDER_WINDOW_MINUTES = 15;

function saoPauloParts(date) {
  const parts = new Intl.DateTimeFormat("en-US", {
    timeZone: "America/Sao_Paulo",
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hourCycle: "h23",
  }).formatToParts(date);
  const get = (type) => parts.find((part) => part.type === type)?.value ?? "00";
  return { year: get("year"), month: get("month"), day: get("day"), hour: get("hour"), minute: get("minute"), second: get("second") };
}

function appointmentInstant(data, hora) {
  return new Date(`${data}T${hora}:00Z`).getTime();
}

function localComparableInstant(date) {
  const local = saoPauloParts(date);
  return Date.UTC(Number(local.year), Number(local.month) - 1, Number(local.day), Number(local.hour), Number(local.minute), Number(local.second));
}

function localDate(date) {
  const local = saoPauloParts(date);
  return `${local.year}-${local.month}-${local.day}`;
}

function normalizePhone(phone) {
  const digits = String(phone).replace(/\D/g, "");
  return digits.startsWith("55") ? digits : `55${digits}`;
}

async function sendWhatsAppReminder(env, to, name, time) {
  if (!env.WHATSAPP_TOKEN || !env.WHATSAPP_PHONE_NUMBER_ID || !env.WHATSAPP_TEMPLATE_NAME) {
    throw new Error("WHATSAPP_TOKEN, WHATSAPP_PHONE_NUMBER_ID e WHATSAPP_TEMPLATE_NAME são obrigatórios.");
  }

  const response = await fetch(
    `https://graph.facebook.com/${env.WHATSAPP_API_VERSION ?? "v22.0"}/${env.WHATSAPP_PHONE_NUMBER_ID}/messages`,
    {
      method: "POST",
      headers: {
        Authorization: `Bearer ${env.WHATSAPP_TOKEN}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        messaging_product: "whatsapp",
        recipient_type: "individual",
        to: normalizePhone(to),
        type: "template",
        template: {
          name: env.WHATSAPP_TEMPLATE_NAME,
          language: { code: env.WHATSAPP_TEMPLATE_LANGUAGE ?? "pt_BR" },
          components: [{
            type: "body",
            parameters: [
              { type: "text", text: name },
              { type: "text", text: time },
            ],
          }],
        },
      }),
    },
  );

  if (response.ok) return { accepted: true };

  const details = `WhatsApp respondeu com ${response.status}: ${await response.text()}`;
  return { accepted: false, retriable: response.status === 429 || response.status >= 500, error: details };
}

async function processReminders(env) {
  const now = new Date();
  const nowMs = localComparableInstant(now);
  const startDate = localDate(now);
  const endDate = localDate(new Date(now.getTime() + 25 * 60 * 60_000));
  const nowIso = now.toISOString();
  const { results } = await env.DB
    .prepare(`SELECT id, nome, whatsapp, data, hora FROM agendamentos
      WHERE status = 'confirmado' AND lembrete_estado = 'pendente' AND lembrete_enviado_em IS NULL
      AND (lembrete_proxima_tentativa_em IS NULL OR lembrete_proxima_tentativa_em <= ?)
      AND data BETWEEN ? AND ?`)
    .bind(nowIso, startDate, endDate)
    .all();

  const candidates = results.filter((appointment) => {
    const minutesUntil = (appointmentInstant(appointment.data, appointment.hora) - nowMs) / 60_000;
    return minutesUntil >= 60 && minutesUntil < 60 + REMINDER_WINDOW_MINUTES;
  });

  for (const appointment of candidates) {
    const claimedAt = new Date().toISOString();
    const claim = await env.DB
      .prepare(`UPDATE agendamentos SET lembrete_estado = 'enviando', lembrete_tentativas = lembrete_tentativas + 1,
        lembrete_reivindicado_em = ?, lembrete_proxima_tentativa_em = NULL, lembrete_erro = NULL, atualizado_em = ?
        WHERE id = ? AND lembrete_estado = 'pendente' AND lembrete_enviado_em IS NULL
        AND (lembrete_proxima_tentativa_em IS NULL OR lembrete_proxima_tentativa_em <= ?)`)
      .bind(claimedAt, claimedAt, appointment.id, nowIso)
      .run();

    if (claim.meta.changes !== 1) continue;

    try {
      const outcome = await sendWhatsAppReminder(env, appointment.whatsapp, appointment.nome, appointment.hora);
      if (!outcome.accepted) {
        const nextAttempt = new Date(Date.now() + 10 * 60_000).toISOString();
        const nextState = outcome.retriable ? "pendente" : "erro";
        await env.DB
          .prepare(`UPDATE agendamentos SET lembrete_estado = ?, lembrete_proxima_tentativa_em = ?, lembrete_erro = ?, atualizado_em = ?
            WHERE id = ? AND lembrete_estado = 'enviando' AND lembrete_reivindicado_em = ?`)
          .bind(nextState, outcome.retriable ? nextAttempt : null, outcome.error, new Date().toISOString(), appointment.id, claimedAt)
          .run();
        continue;
      }
      const sentAt = new Date().toISOString();
      await env.DB
        .prepare(`UPDATE agendamentos SET lembrete_estado = 'enviado', lembrete_enviado_em = ?, atualizado_em = ?
          WHERE id = ? AND lembrete_estado = 'enviando' AND lembrete_reivindicado_em = ?`)
        .bind(sentAt, sentAt, appointment.id, claimedAt)
        .run();
    } catch (error) {
      // Falhas de rede após o envio são ambíguas: não reenviar automaticamente evita mensagem duplicada.
      await env.DB
        .prepare(`UPDATE agendamentos SET lembrete_estado = 'erro', lembrete_erro = ?, atualizado_em = ?
          WHERE id = ? AND lembrete_estado = 'enviando' AND lembrete_reivindicado_em = ?`)
        .bind(String(error), new Date().toISOString(), appointment.id, claimedAt)
        .run();
      console.error(`Lembrete ${appointment.id} requer verificação:`, error);
    }
  }
}

export default {
  async scheduled(_controller, env, ctx) {
    ctx.waitUntil(processReminders(env));
  },
};

export { appointmentInstant, localComparableInstant, processReminders, saoPauloParts };
