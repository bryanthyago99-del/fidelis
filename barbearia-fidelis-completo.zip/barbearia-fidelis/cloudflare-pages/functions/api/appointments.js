const ALLOWED_TIMES = new Set([
  "08:00", "08:40", "09:20", "10:00", "10:40", "11:20", "12:00", "12:40", "13:20",
  "14:00", "14:40", "15:20", "16:00", "16:40", "17:20", "18:00", "18:40", "19:20", "20:00",
]);

function json(data, status = 200) {
  return Response.json(data, { status, headers: { "cache-control": "no-store" } });
}

function normalizeWhatsApp(value) {
  const digits = String(value ?? "").replace(/\D/g, "");
  return digits.startsWith("55") ? digits : `55${digits}`;
}

function validDate(value) {
  const parsed = new Date(`${value}T12:00:00Z`);
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function saoPauloDateTime() {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date());
  const get = (type) => parts.find((part) => part.type === type)?.value ?? "";
  return { date: `${get("year")}-${get("month")}-${get("day")}`, time: `${get("hour")}:${get("minute")}` };
}

export async function onRequestPost({ env, request }) {
  let body;
  try {
    body = await request.json();
  } catch {
    return json({ error: "Dados de agendamento inválidos." }, 400);
  }

  const nome = String(body.nome ?? "").trim();
  const whatsapp = normalizeWhatsApp(body.whatsapp);
  const data = String(body.data ?? "");
  const hora = String(body.hora ?? "");

  const now = saoPauloDateTime();
  if (nome.length < 2 || nome.length > 100 || !/^\d{12,13}$/.test(whatsapp) || !validDate(data) || data < now.date || (data === now.date && hora <= now.time) || !ALLOWED_TIMES.has(hora)) {
    return json({ error: "Revise os dados do agendamento e tente novamente." }, 400);
  }

  try {
    const result = await env.DB
      .prepare("INSERT INTO agendamentos (nome, whatsapp, data, hora, status) VALUES (?, ?, ?, ?, 'confirmado')")
      .bind(nome, whatsapp, data, hora)
      .run();

    return json({ id: result.meta.last_row_id, data, hora, status: "confirmado" }, 201);
  } catch (error) {
    if (String(error).includes("UNIQUE constraint failed")) {
      return json({ error: "Esse horário acabou de ser reservado. Escolha outro." }, 409);
    }
    console.error("Falha ao criar agendamento", error);
    return json({ error: "Não foi possível registrar seu agendamento agora." }, 500);
  }
}
