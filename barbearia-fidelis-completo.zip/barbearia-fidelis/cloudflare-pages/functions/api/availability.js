const ALLOWED_TIMES = new Set([
  "08:00", "08:40", "09:20", "10:00", "10:40", "11:20", "12:00", "12:40", "13:20",
  "14:00", "14:40", "15:20", "16:00", "16:40", "17:20", "18:00", "18:40", "19:20", "20:00",
]);

function json(data, status = 200) {
  return Response.json(data, { status, headers: { "cache-control": "no-store" } });
}

function validDate(value) {
  const parsed = new Date(`${value}T12:00:00Z`);
  return /^\d{4}-\d{2}-\d{2}$/.test(value) && !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === value;
}

function saoPauloDateTime() {
  const parts = new Intl.DateTimeFormat("en-US", { timeZone: "America/Sao_Paulo", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date());
  const get = (type) => parts.find((part) => part.type === type)?.value ?? "";
  return { date: `${get("year")}-${get("month")}-${get("day")}`, time: `${get("hour")}:${get("minute")}` };
}

export async function onRequestGet({ env, request }) {
  const date = new URL(request.url).searchParams.get("data") ?? "";
  const now = saoPauloDateTime();
  if (!validDate(date) || date < now.date) return json({ error: "Informe uma data válida." }, 400);

  const { results } = await env.DB
    .prepare("SELECT hora FROM agendamentos WHERE data = ? AND status = 'confirmado'")
    .bind(date)
    .all();

  const bookedTimes = results.map((item) => item.hora).filter((time) => ALLOWED_TIMES.has(time));
  if (date === now.date) bookedTimes.push(...[...ALLOWED_TIMES].filter((time) => time <= now.time));
  return json({ bookedTimes });
}
