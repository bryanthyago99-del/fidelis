# Barbearia Fidelis — Cloudflare Pages

Este diretório é o pacote de publicação independente da landing page e do agendamento. Ele usa **HTML, CSS e JavaScript puros** no frontend, **Cloudflare Pages Functions** para a API de reservas, **Cloudflare D1 (SQLite)** para persistência e um **Cloudflare Worker** separado para disparar os lembretes programados. A separação é intencional: Pages Functions atendem a aplicação web e um Worker com `scheduled()` executa o cron a cada 10 minutos. A própria Cloudflare documenta bindings D1 para Pages Functions e gatilhos de cron em Workers [1] [2].

> Antes de publicar, substitua todas as ocorrências de `barbearia-fidelis.pages.dev` pelo domínio definitivo. Isso inclui `index.html`, `robots.txt`, `sitemap.xml` e `llms.txt`.

## Estrutura

| Caminho | Finalidade |
|---|---|
| `index.html` | Landing page com fluxo de agendamento em três etapas. |
| `css/style.css` e `js/app.js` | Interface responsiva, acessível e lógica pública do formulário. |
| `functions/api/availability.js` | Consulta horários indisponíveis no D1. |
| `functions/api/appointments.js` | Cria a reserva, valida dados e impede conflito por `UNIQUE (data, hora)`. A grade inclui 08:00–20:00 em passos de 40 minutos. |
| `schema.sql` | Esquema D1 com estado de lembrete idempotente. |
| `worker/` | Worker separado que executa o cron e chama o WhatsApp Business Platform. |
| `privacidade.html`, `termos.html`, `404.html` | Páginas institucionais e de erro. |
| `robots.txt`, `sitemap.xml`, `llms.txt` | Descoberta para busca e sistemas de IA. |

## Publicação no GitHub e Cloudflare Pages

Crie um repositório Git com o conteúdo deste diretório na raiz e envie-o para o GitHub. No Cloudflare Dashboard, crie um projeto Pages conectado ao repositório, sem comando de build e com diretório de saída definido como `.`. Em **Settings → Bindings**, vincule o banco D1 criado abaixo com o nome `DB`. As Pages Functions acessam o binding em `env.DB`, que é o padrão de integração documentado para D1 [1].

```bash
npx wrangler d1 create barbearia-fidelis
# Copie o database_id retornado para o campo database_id em wrangler.toml.

npx wrangler d1 execute barbearia-fidelis --remote --file=./schema.sql
```

O arquivo `wrangler.toml` deste diretório é uma referência de binding. No fluxo de Git integrado ao Pages, também é possível fazer a associação do banco diretamente no painel do projeto e manter o arquivo apenas para desenvolvimento local.

## Worker de lembretes

Na pasta `worker`, substitua o `database_id` pelo mesmo ID do D1 e publique o Worker. O cron `*/10 * * * *` é executado a cada dez minutos em UTC, como definido na configuração `triggers.crons` [2]. O código converte a comparação para o fuso `America/Sao_Paulo` antes de avaliar a janela de uma hora.

```bash
cd worker
npx wrangler secret put WHATSAPP_TOKEN
npx wrangler secret put WHATSAPP_PHONE_NUMBER_ID
npx wrangler deploy
```

Para mensagens iniciadas pela empresa fora da janela de atendimento de 24 horas, a API oficial do WhatsApp exige um **template pré-aprovado**, e o destinatário deve ter optado por receber mensagens [3]. No WhatsApp Manager, crie e aprove um template de utilidade em `pt_BR` com o corpo exato:

```text
Fala {{1}}! Seu horário é em 1h às {{2}}
```

Em seguida, defina o nome real do template em `worker/wrangler.toml`, na variável `WHATSAPP_TEMPLATE_NAME`. O Worker envia os parâmetros `nome` e `hora`, reivindica a reserva antes do envio e somente marca como `enviado` após o aceite da API. Esse desenho impede disparos duplicados em execuções concorrentes. Respostas `429` e `5xx` retornam o registro a `pendente` para nova tentativa segura após dez minutos; falhas de rede, configuração ou respostas definitivas são registradas como `erro`, pois repetir um envio de resultado ambíguo poderia duplicar a mensagem.

## Fotos autorizadas do Instagram

A estrutura visual da galeria está pronta, mas as imagens não foram extraídas automaticamente porque o perfil oficial exige login no ambiente de desenvolvimento. Para concluir a galeria sem uso indevido de conteúdo, inclua três fotos fornecidas ou autorizadas pela Barbearia Fidelis e atualize os cartões em `index.html` com seus links públicos otimizados.

## Verificação local

Para desenvolvimento com Pages Functions e D1 local, instale o Wrangler e execute o projeto a partir deste diretório. A documentação da Cloudflare mostra como vincular o D1 em ambiente local e testar o cron pelo caminho local de agendamento [1] [2].

```bash
npx wrangler pages dev . --d1 DB=SUBSTITUA_PELO_ID_DO_D1
# Em outra verificação, para o Worker:
cd worker && npx wrangler dev --test-scheduled
```

## Referências

[1]: https://developers.cloudflare.com/pages/functions/bindings/ "Bindings — Cloudflare Pages"
[2]: https://developers.cloudflare.com/workers/configuration/cron-triggers/ "Cron Triggers — Cloudflare Workers"
[3]: https://developers.facebook.com/documentation/business-messaging/whatsapp/messages/send-messages "Service messages — Meta for Developers"
