-- Barbearia Fidelis · Cloudflare D1 / SQLite
-- Datas e horários são armazenados no fuso local informado ao cliente (America/Sao_Paulo).
CREATE TABLE IF NOT EXISTS agendamentos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  nome TEXT NOT NULL CHECK (length(trim(nome)) BETWEEN 2 AND 100),
  whatsapp TEXT NOT NULL CHECK (length(whatsapp) BETWEEN 12 AND 13),
  data TEXT NOT NULL CHECK (data GLOB '____-__-__'),
  hora TEXT NOT NULL CHECK (hora IN (
    '08:00', '08:40', '09:20', '10:00', '10:40', '11:20', '12:00', '12:40', '13:20',
    '14:00', '14:40', '15:20', '16:00', '16:40', '17:20', '18:00', '18:40', '19:20', '20:00'
  )),
  status TEXT NOT NULL DEFAULT 'confirmado' CHECK (status IN ('confirmado', 'cancelado')),
  lembrete_estado TEXT NOT NULL DEFAULT 'pendente' CHECK (lembrete_estado IN ('pendente', 'enviando', 'enviado', 'erro')),
  lembrete_tentativas INTEGER NOT NULL DEFAULT 0,
  lembrete_proxima_tentativa_em TEXT,
  lembrete_reivindicado_em TEXT,
  lembrete_enviado_em TEXT,
  lembrete_erro TEXT,
  criado_em TEXT NOT NULL DEFAULT (datetime('now')),
  atualizado_em TEXT NOT NULL DEFAULT (datetime('now')),
  UNIQUE (data, hora)
);

CREATE INDEX IF NOT EXISTS idx_agendamentos_data_status ON agendamentos (data, status);
CREATE INDEX IF NOT EXISTS idx_agendamentos_lembrete ON agendamentos (lembrete_estado, lembrete_proxima_tentativa_em, lembrete_enviado_em);
