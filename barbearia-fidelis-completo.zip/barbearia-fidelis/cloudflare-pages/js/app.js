const SLOTS = ["08:00", "08:40", "09:20", "10:00", "10:40", "11:20", "12:00", "12:40", "13:20", "14:00", "14:40", "15:20", "16:00", "16:40", "17:20", "18:00", "18:40", "19:20", "20:00"];
const booking = document.querySelector("#booking-content");
const steps = [...document.querySelectorAll(".steps span")];
const state = { step: 1, date: "", time: "", name: "", whatsapp: "", dates: nextDates() };

function nextDates() {
  const days = [];
  const date = new Date();
  date.setHours(12, 0, 0, 0);
  for (let index = 0; index < 6; index += 1) {
    days.push(new Date(date));
    date.setDate(date.getDate() + 1);
  }
  return days;
}

function iso(date) { return date.toISOString().slice(0, 10); }
function escapeHtml(value) { return String(value).replace(/[&<>'"]/g, (character) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", "'": "&#39;", '"': "&quot;" }[character])); }
function phoneMask(value) { const digits = value.replace(/\D/g, "").slice(0, 11); return digits.length <= 2 ? digits : digits.length <= 7 ? `(${digits.slice(0, 2)}) ${digits.slice(2)}` : `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`; }
function selectedDateText() { const date = state.dates.find((item) => iso(item) === state.date); return date ? date.toLocaleDateString("pt-BR", { weekday: "long", day: "2-digit", month: "long" }) : state.date; }
function updateSteps() { steps.forEach((item, index) => item.classList.toggle("active", index < state.step)); document.querySelector(".steps").setAttribute("aria-label", `Etapa ${state.step} de 3`); }

function renderDateStep() {
  booking.innerHTML = `<div class="booking-step"><p class="step-label">PASSO 01 · DATA</p><h3>Qual dia funciona para você?</h3><div class="date-grid" role="group" aria-label="Escolha a data">${state.dates.map((date) => { const value = iso(date); return `<button class="date-chip" type="button" data-date="${value}" aria-pressed="${state.date === value}"><span class="date-chip__weekday">${date.toLocaleDateString("pt-BR", { weekday: "short" }).replace(".", "")}</span><span class="date-chip__number">${date.getDate()}</span></button>`; }).join("")}</div></div><div class="booking-footer"><span class="step-label">Selecione uma data</span></div>`;
  booking.querySelectorAll("[data-date]").forEach((button) => button.addEventListener("click", () => { state.date = button.dataset.date; state.time = ""; state.step = 2; render(); }));
}

async function renderTimeStep() {
  booking.innerHTML = `<div class="booking-step"><p class="step-label">PASSO 02 · HORÁRIO</p><h3>Escolha um horário livre.</h3><div class="feedback">Consultando disponibilidade...</div></div><div class="booking-footer"><span class="step-label">${escapeHtml(selectedDateText())}</span><button class="back-button" type="button" data-back>Voltar</button></div>`;
  booking.querySelector("[data-back]").addEventListener("click", () => { state.step = 1; render(); });
  try {
    const response = await fetch(`/api/availability?data=${encodeURIComponent(state.date)}`, { headers: { Accept: "application/json" } });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Não foi possível consultar a agenda.");
    const booked = new Set(payload.bookedTimes || []);
    booking.innerHTML = `<div class="booking-step"><p class="step-label">PASSO 02 · HORÁRIO</p><h3>Escolha um horário livre.</h3><div class="slot-grid" role="group" aria-label="Escolha o horário">${SLOTS.map((time) => `<button class="slot" type="button" data-time="${time}" aria-pressed="${state.time === time}" ${booked.has(time) ? "disabled" : ""}>${time}</button>`).join("")}</div></div><div class="booking-footer"><span class="step-label">${escapeHtml(selectedDateText())}</span><button class="back-button" type="button" data-back>Voltar</button></div>`;
    booking.querySelector("[data-back]").addEventListener("click", () => { state.step = 1; render(); });
    booking.querySelectorAll("[data-time]").forEach((button) => button.addEventListener("click", () => { state.time = button.dataset.time; state.step = 3; render(); }));
  } catch (error) {
    booking.innerHTML = `<div class="booking-step"><p class="step-label">PASSO 02 · HORÁRIO</p><h3>Escolha um horário livre.</h3><p class="feedback feedback--error" role="alert">${escapeHtml(error.message)}</p></div><div class="booking-footer"><span></span><button class="back-button" type="button" data-back>Voltar</button></div>`;
    booking.querySelector("[data-back]").addEventListener("click", () => { state.step = 1; render(); });
  }
}

function renderFormStep() {
  booking.innerHTML = `<form class="booking-step" id="appointment-form"><p class="step-label">PASSO 03 · CONFIRMAÇÃO</p><h3>Falta pouco.</h3><div class="form-grid"><label>Seu nome<input name="name" autocomplete="name" minlength="2" maxlength="100" required placeholder="Como podemos te chamar?" value="${escapeHtml(state.name)}"></label><label>Seu WhatsApp<input name="whatsapp" autocomplete="tel" inputmode="numeric" minlength="14" required placeholder="(00) 00000-0000" value="${escapeHtml(state.whatsapp)}"></label></div><p class="feedback feedback--error" hidden role="alert"></p><div class="booking-footer"><button class="back-button" type="button" data-back>Voltar</button><button class="button button--orange" type="submit">Confirmar</button></div></form>`;
  booking.querySelector("[data-back]").addEventListener("click", () => { state.step = 2; render(); });
  booking.querySelector("[name=whatsapp]").addEventListener("input", (event) => { event.target.value = phoneMask(event.target.value); });
  booking.querySelector("#appointment-form").addEventListener("submit", submitAppointment);
}

async function submitAppointment(event) {
  event.preventDefault();
  const form = new FormData(event.currentTarget);
  state.name = String(form.get("name") || "").trim();
  state.whatsapp = String(form.get("whatsapp") || "");
  const submit = event.currentTarget.querySelector("[type=submit]");
  const feedback = event.currentTarget.querySelector(".feedback");
  submit.disabled = true; submit.textContent = "Confirmando..."; feedback.hidden = true;
  try {
    const response = await fetch("/api/appointments", { method: "POST", headers: { "Content-Type": "application/json", Accept: "application/json" }, body: JSON.stringify({ nome: state.name, whatsapp: state.whatsapp, data: state.date, hora: state.time }) });
    const payload = await response.json();
    if (!response.ok) throw new Error(payload.error || "Não foi possível registrar seu agendamento agora.");
    booking.innerHTML = `<div class="success" role="status"><span class="success__icon" aria-hidden="true">✓</span><h3>Horário reservado.</h3><p>Seu agendamento para ${escapeHtml(selectedDateText())} às ${escapeHtml(state.time)} foi registrado. Você receberá um lembrete pelo WhatsApp.</p><button class="back-button" type="button" data-restart>Fazer novo agendamento</button></div>`;
    booking.querySelector("[data-restart]").addEventListener("click", () => { state.step = 1; state.time = ""; state.name = ""; state.whatsapp = ""; render(); });
  } catch (error) {
    submit.disabled = false; submit.textContent = "Confirmar"; feedback.textContent = error.message; feedback.hidden = false;
  }
}

function render() { updateSteps(); if (state.step === 1) renderDateStep(); else if (state.step === 2) renderTimeStep(); else renderFormStep(); }
render();
