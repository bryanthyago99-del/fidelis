export const APPOINTMENT_START_HOUR = 8;
export const APPOINTMENT_END_HOUR = 20;
export const APPOINTMENT_INTERVAL_MINUTES = 40;

/**
 * A agenda apresenta todos os inícios em intervalos de 40 minutos, de 08:00
 * até 20:00, inclusive, conforme o requisito operacional da barbearia.
 */
export const APPOINTMENT_SLOTS = Array.from({ length: 19 }, (_, index) => {
  const totalMinutes = APPOINTMENT_START_HOUR * 60 + index * APPOINTMENT_INTERVAL_MINUTES;
  const hour = Math.floor(totalMinutes / 60).toString().padStart(2, "0");
  const minute = (totalMinutes % 60).toString().padStart(2, "0");
  return `${hour}:${minute}`;
});

export const DATE_PATTERN = /^\d{4}-\d{2}-\d{2}$/;
export const WHATSAPP_DIGITS_PATTERN = /^\d{10,13}$/;

export function isValidAppointmentDate(date: string) {
  if (!DATE_PATTERN.test(date)) return false;
  const parsed = new Date(`${date}T12:00:00`);
  return !Number.isNaN(parsed.getTime()) && parsed.toISOString().slice(0, 10) === date;
}

export function normalizeWhatsApp(value: string) {
  const digits = value.replace(/\D/g, "");
  return digits.startsWith("55") ? digits : `55${digits}`;
}

export function isValidWhatsApp(value: string) {
  return WHATSAPP_DIGITS_PATTERN.test(normalizeWhatsApp(value));
}

export function isAllowedAppointmentTime(time: string) {
  return APPOINTMENT_SLOTS.includes(time);
}
