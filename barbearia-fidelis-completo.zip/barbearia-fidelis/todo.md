# Project TODO

- [x] Criar landing page pública, responsiva e minimalista em modo escuro com a identidade preto, laranja e branco da Barbearia Fidelis.
- [x] Implementar CTA e fluxo público de agendamento em três etapas: data, horário e identificação do cliente.
- [x] Restringir a grade de horários a 08:00–20:00, em blocos fixos de 40 minutos, sem exibir serviços ou preços.
- [x] Aplicar máscara e validação de nome, telefone brasileiro e data futura no formulário.
- [x] Implementar API de disponibilidade e criação de reservas com prevenção de conflito no mesmo dia e horário.
- [x] Criar o esquema Cloudflare D1/SQLite com id, nome, whatsapp, data, hora, status, lembrete e restrições de unicidade.
- [x] Preparar Pages Functions para disponibilidade e criação de agendamentos no caminho /functions/api/.
- [x] Preparar Worker programado a cada 10 minutos para localizar reservas em uma hora e disparar lembretes de forma idempotente.
- [x] Configurar contrato de variáveis de ambiente para o provedor oficial de WhatsApp, sem expor credenciais no cliente.
- [x] Implementar galeria com três espaços para fotos autorizadas e link para o perfil oficial da barbearia no Instagram.
- [x] Criar páginas de Privacidade, Termos e 404 com navegação de retorno e texto adequado à LGPD.
- [x] Implementar metatags, Open Graph, JSON-LD LocalBusiness, robots.txt, sitemap.xml e llms.txt voltados a Campestre-MG.
- [x] Criar configuração Wrangler, documentação de implantação em GitHub/Cloudflare Pages e instruções para migrar o banco D1.
- [x] Cobrir regras críticas com testes automatizados, validar a interface em desktop e mobile e revisar acessibilidade WCAG AA.
- [ ] Substituir os três cartões visuais da galeria pelas três fotos autorizadas fornecidas pela Barbearia Fidelis.
- [x] Implementar reprocessamento seguro para falhas inequívocas de lembrete, com bloqueio temporário, contagem de tentativas e registro de falhas ambíguas para evitar duplicidade.
- [x] Ampliar os testes automatizados para Pages Functions, conflito de reserva, horários passados e worker de lembretes, e registrar a revisão objetiva de acessibilidade.
